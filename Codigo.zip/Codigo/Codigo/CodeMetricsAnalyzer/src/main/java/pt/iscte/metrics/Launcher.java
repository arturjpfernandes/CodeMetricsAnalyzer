package pt.iscte.metrics;

public class Launcher {
    public static void main(String[] args) {
        App.main(args);
    }
}