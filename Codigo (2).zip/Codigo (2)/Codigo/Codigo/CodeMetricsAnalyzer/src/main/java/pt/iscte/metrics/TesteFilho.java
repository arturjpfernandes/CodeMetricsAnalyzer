package pt.iscte.metrics;
public class TesteFilho extends TestePai { }