package pt.iscte.metrics;
public class TestePai { }